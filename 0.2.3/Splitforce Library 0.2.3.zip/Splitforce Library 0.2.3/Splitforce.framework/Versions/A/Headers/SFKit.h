/*!
 @header    SFKit.h
 @abstract  Splitforce iOS SDK Header
 @version   1.0
 @copyright Copyright 2013 Ikura Group Limited. All rights reserved.
 */



#import <Foundation/Foundation.h>

#import <Splitforce/SFManager.h>
#import <Splitforce/SFVariation.h>
#import <Splitforce/SFUtils.h>